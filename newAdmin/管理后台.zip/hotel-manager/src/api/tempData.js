export const analysisMenu = [
	{
		title: '实时数据', route: 'actual', children: [
			{title: '采集数据查询', route: 'collectData'},
			{title: '电量点位查询', route: 'roomPoint'},
			{title: '电量对比查询', route: 'comparedEle'},
			{title: '电量数据查询', route: 'eleData'},
			{title: '终端数据查询', route: 'terminalData'},
		]
	},
	{
		title: '实时数据', route: 'actual', children: [
			{title: '采集数据查询', route: 'collectData'},
			{title: '电量点位查询', route: 'roomPoint'},
			{title: '电量对比查询', route: 'comparedEle'},
			{title: '电量数据查询', route: 'eleData'},
			{title: '终端数据查询', route: 'terminalData'},
		]
	},
	{
		title: '实时数据', route: 'actual', children: [
			{title: '采集数据查询', route: 'collectData'},
			{title: '电量点位查询', route: 'roomPoint'},
			{title: '电量对比查询', route: 'comparedEle'},
			{title: '电量数据查询', route: 'eleData'},
			{title: '终端数据查询', route: 'terminalData'},
		]
	},
	{
		title: '实时数据', route: 'actual', children: [
			{title: '采集数据查询', route: 'collectData'},
			{title: '电量点位查询', route: 'roomPoint'},
			{title: '电量对比查询', route: 'comparedEle'},
			{title: '电量数据查询', route: 'eleData'},
			{title: '终端数据查询', route: 'terminalData'},
		]
	},
	{
		title: '实时数据', route: 'actual', children: [
			{title: '采集数据查询', route: 'collectData'},
			{title: '电量点位查询', route: 'roomPoint'},
			{title: '电量对比查询', route: 'comparedEle'},
			{title: '电量数据查询', route: 'eleData'},
			{title: '终端数据查询', route: 'terminalData'},
		]
	},

]
