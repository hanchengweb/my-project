<template>
	<searchTable class="searchTableSingle"></searchTable>
</template>
<script>
	import searchTable from '@/components/searchTable/searchTable'

	export default {
		components: {
			searchTable
		}
	}
</script>
<style lang="less">

</style>
