<template>
	<warnInfo></warnInfo>
</template>
<script>
	import warnInfo from '@/view/common/warnInfo/warnInfo2'

	export default {
		components: {
			warnInfo
		}
	}
</script>
