export const homeMixins = {
	mounted () {

	}
}
