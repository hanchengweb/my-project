import table from './table'

export default table
