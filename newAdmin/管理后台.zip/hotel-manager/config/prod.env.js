'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // 测试环境
  API_ROOT: '"http://192.168.1.95/api/"',
  UPLOAD_ROOT: '"http://192.168.1.95/api/"'
  // 生产环境
  // API_ROOT: '"http://power.hztaijue.com/api/"',
  // UPLOAD_ROOT: '"http://power.hztaijue.com/api/"'
  /* API_ROOT: '"http://192.168.1.95/api/"',
	UPLOAD_ROOT: '"http://192.168.1.95/api/"', */
}
