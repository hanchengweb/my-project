import Vue from 'vue'
import App from './seCode'

const app = new Vue(App)
app.$mount()
