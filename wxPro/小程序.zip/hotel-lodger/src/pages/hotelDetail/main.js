import Vue from 'vue'
import App from './hotelDetail'

const app = new Vue(App)
app.$mount()
