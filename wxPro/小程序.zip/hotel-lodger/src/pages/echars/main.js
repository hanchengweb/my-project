import Vue from 'vue'
import App from './echars'

const app = new Vue(App)
app.$mount()
