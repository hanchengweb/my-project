import Vue from 'vue'
import App from './sign'

const app = new Vue(App)
app.$mount()
