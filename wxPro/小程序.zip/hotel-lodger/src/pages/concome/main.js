import Vue from 'vue'
import App from './concome'

const app = new Vue(App)
app.$mount()
