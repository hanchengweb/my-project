import Vue from 'vue'
import App from './explain'

const app = new Vue(App)
app.$mount()
