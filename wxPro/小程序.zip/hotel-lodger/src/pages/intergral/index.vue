<template>
  <div>
     积分
  </div>
</template>

<script>
</script>

<style>

</style>
