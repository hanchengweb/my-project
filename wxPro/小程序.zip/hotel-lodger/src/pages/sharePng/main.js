import Vue from 'vue'
import App from './sharePng'

const app = new Vue(App)
app.$mount()
