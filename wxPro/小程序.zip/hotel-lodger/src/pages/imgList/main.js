import Vue from 'vue'
import App from './imgList'

const app = new Vue(App)
app.$mount()
